import React from 'react';
import axios from 'axios';

const ProjectTable = ({ projects, fetchProjects }) => {
    const handleDelete = async (id) => {
        await axios.delete(`http://localhost:8000/api/projects/${id}`);
        fetchProjects();
    };

    return (
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                {projects.map((project) => (
                    <tr key={project.id}>
                        <td>{project.name}</td>
                        <td>{project.description}</td>
                        <td>{project.status}</td>
                        <td>
                            <button onClick={() => handleDelete(project.id)}>Delete</button>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    );
};

export default ProjectTable;
