import React, { useState } from 'react';
import axios from 'axios';

const ProjectForm = ({ fetchProjects }) => {
    const [form, setForm] = useState({ name: '', description: '', status: 'active' });

    const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

    const handleSubmit = async (e) => {
        e.preventDefault();
        await axios.post('http://localhost:8000/api/projects', form);
        fetchProjects();
    };

    return (
        <form onSubmit={handleSubmit}>
            <input name="name" placeholder="Name" value={form.name} onChange={handleChange} required />
            <textarea name="description" placeholder="Description" value={form.description} onChange={handleChange} required />
            <select name="status" value={form.status} onChange={handleChange}>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="completed">Completed</option>
            </select>
            <button type="submit">Create Project</button>
        </form>
    );
};

export default ProjectForm;
