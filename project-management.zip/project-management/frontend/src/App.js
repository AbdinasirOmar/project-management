import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ProjectForm from './ProjectForm';
import ProjectTable from './ProjectTable';

const App = () => {
    const [projects, setProjects] = useState([]);

    const fetchProjects = async () => {
        const { data } = await axios.get('http://localhost:8000/api/projects');
        setProjects(data);
    };

    useEffect(() => {
        fetchProjects();
    }, []);

    return (
        <div>
            <h1>Project Management</h1>
            <ProjectForm fetchProjects={fetchProjects} />
            <ProjectTable projects={projects} fetchProjects={fetchProjects} />
        </div>
    );
};

export default App;
