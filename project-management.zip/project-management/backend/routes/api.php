<?php
use App\Http\Controllers\ProjectController;

Route::apiResource('projects', ProjectController::class);
